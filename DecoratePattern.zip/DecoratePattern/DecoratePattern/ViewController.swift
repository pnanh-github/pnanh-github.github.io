//
//  ViewController.swift
//  DecoratePattern
//
//  Created by Pham Nhat Anh on 12/21/17.
//  Copyright © 2017 Yam Media. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    var computer: Computer!
    override func viewDidLoad() {
        super.viewDidLoad()
//        let products = [(1, "Sql for dummies ", 20.0,3), (2, "Sql for dummies 2", 20.0,3), (3, "Sql for dummies 3", 20.0,3)]
//        let total = products.reduce(10 ,{ (total, product) -> Double in
//            return total + product.2
//        })
//        print(total) //70
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    deinit {
        print("deinit ViewVC")
    }
    
    fileprivate func showComputerInfo() {
        let alert = UIAlertController.init(title: computer.description(), message: nil, preferredStyle: UIAlertControllerStyle.alert)
        alert.addAction(UIAlertAction.init(title: "OK", style: .cancel, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }
    
    @IBAction func addComputer(_ sender: Any) {
        computer = Computer()
        (sender as! UIButton).isEnabled = false
        showComputerInfo()
    }
    @IBAction func addMouse(_ sender: Any) {
        if computer != nil {
            computer = Mouse(computer)
            showComputerInfo()
        }
    }
    @IBAction func addKeyboard(_ sender: Any) {
        if computer != nil {
            computer = Keyboard(computer)
            showComputerInfo()
        }
    }
    @IBAction func addMoniter(_ sender: Any) {
        if computer != nil {
            computer = Moniter(computer)
            showComputerInfo()
        }
    }
}

class Computer {
    func description() -> String{
        return "I have computer"
    }
}

class DecorateComponent: Computer {
    var wrappedComputer: Computer!
    init(_ computer: Computer) {
        super.init()
        wrappedComputer = computer
    }
}

class Mouse: DecorateComponent {
    override func description() -> String {
        return "\(wrappedComputer.description()) and a mouse"
    }
}

class Keyboard: DecorateComponent {
    override func description() -> String {
      return "\(wrappedComputer.description()) and a keyboard"
    }
}

class Moniter: DecorateComponent {
    override func description() -> String {
       return "\(wrappedComputer.description()) and a Moniter"
    }
}
